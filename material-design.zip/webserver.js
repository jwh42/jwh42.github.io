const http = require('http');
const path = require('path');
const url = require('url');
const fs = require('fs');


/**
 * Basic HTTP test server
 */
class HttpTestServer {


	/**
	 * Constructs a new instance
	 * @param {string} baseFilePath Base file path
	 * @param {number} serverPort Port number for the server
	 */
	constructor(baseFilePath, serverPort) {

		this.baseFilePath = baseFilePath;
		this.defaultFile = "index.html";
		this.serverPort = serverPort;

		this.mimeTypes = {
			offline: "text/cache-manifest",
			map: "application/json",
			json: "application/json",
			glsl: "text/plain",
			css: "text/css",
			html: "text/html",
			js: "application/javascript",
			gif: "image/gif",
			png: "image/png",
			jpg: "image/jpeg",
			txt: "text/plain",
		}
	}

	/**
	 * Starts the web server
	 */
	start() {

		console.log("starting web server");
		console.log(`path=${this.baseFilePath}`);
		console.log(`port=${this.serverPort}`);
		console.log('');

		http
			.createServer((request, response) => {
				this._handleRequest(request, response);
			})
			.listen(this.serverPort);

		return this;
	}


	_handleRequest(request, response) {

		const urlParts = url.parse(request.url);
		const fileName = urlParts.pathname;
		const fileExtn = this._getFileExtn(fileName);
		const mimeType = this.mimeTypes[fileExtn] || this.mimeTypes.txt;

		let fullPath = path.join(this.baseFilePath, fileName);
		let content = null;

		console.log(`${request.method} ${request.url}`);

		try {
			if(fs.lstatSync(fullPath).isDirectory()) {
				if(!fileName.endsWith("/")) { // paths must end with '/'
					this._handleRedirect(response, `${fileName}/`);
					return;
				}
				fullPath = path.join(fullPath, this.defaultFile);
			}

			response.writeHead(200, {'Content-Type': mimeType});
			response.end(fs.readFileSync(fullPath));

		} catch(e) {
			this._handleError(response, fileName, e);
		}
	}


	_handleRedirect(response, dest) {

		console.log(`>>> ${dest}`)
		response.writeHead(302, { "Location": dest });
		response.end();
	}


	_handleError(response, fileName, error) {

		response.writeHead(404, {'Content-Type': this.mimeTypes.txt});
		response.write("Could not get '" + fileName +"':\r\n");
		response.write(error.message);
		response.end();
	}


	_getFileExtn(fileName) {

		const dotIndex = fileName.lastIndexOf('.');
		return (dotIndex >= 0)
			? fileName.substr(dotIndex+1)
			: "html";
	}
}


new HttpTestServer(__dirname, 80).start();
